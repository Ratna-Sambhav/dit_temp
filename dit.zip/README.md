---
title: Dit Document Layout Analysis
emoji: 👀
colorFrom: purple
colorTo: red
sdk: gradio
sdk_version: 2.8.9
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces#reference
